import csv
import sys
import warnings
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException
import json
import pymongo

uri = "mongodb://dan:hackingdandy1@ds143573.mlab.com:43573/dandyhacks-2018"


try:
    import bs4
except ImportError:
    warnings.warn("dependency not found, please install bs4")
try:
    import requests
except ImportError:
    warnings.warn("dependency not found, please install requests")


class flight:

    def __init__(self, flightNum, date, time):
        self.date = date
        self.time = time
        self.flightNum = flightNum


    def printData(self):
        print(self.date + " : "+ self.time)



def getFlights(soupDataLocal,flightData):
    initial = (soupDataLocal.find(attrs={"data-ng-app":"fr24App"}))
    subPage = initial.find(attrs={"id":"cnt-data-subpage"})
    airportCtrl = subPage.find(attrs={"data-ng-controller":"AirportsDataCtrl"})
    p4 = airportCtrl.find(attrs={"id":"cnt-data-content"})
    p5 = p4.find(attrs={"class":"tab-content"})
    p6 = p5.find(attrs={"class":"tab-pane p-l active"})
    p7 = p6.find(attrs={"class":"row"})
    p8 = p7.find(attrs={"class":"col-sm-12 airport-schedule-data"})
    p9 = p8.find(attrs={"class":"row cnt-schedule-table"})
    p10 = p9.find(attrs={"class":"table table-condensed table-hover data-table m-n-t-15"})
    p11 = p10.find("tbody")
    p12 = p11.find_all("tr")
    for x in p12:
        date = ""
        time = ""
        id = ""
        if x.has_attr('data-date'):
            date = str(x['data-date'])
        if date is not None:
            flightNum = x.find("td", "p-l-s cell-flight-number")
            if flightNum is not None:
                idA = flightNum.find("a", "notranslate ng-binding")
                idNum = str(idA['title'])
                print(id)
                for fl in flightData:
                    if fl.flightNum == idNum:
                        idNum = None
                        break
                if idNum is "":
                    continue
            td = x.find_all("td", class_="ng-binding")
            for t in td:
                temp = ''.join(t.text)
                temp.strip()
                stringBuilder = ""
                time = ""
                for i in temp:
                    i = str(i)
                    stringBuilder+=i
                    if i is not " ":
                        time +=stringBuilder
                        stringBuilder = ""
                break
        if date is "" or time is "":
            continue
        else:
            f = flight(idNum, date, time)
            flightData.append(f)
    return flightData


def parseData(ogData):

    Dates = {}
    for f in ogData:
        locDate = parseDate(f.date)
        print(locDate)
        loctime = parseTime(f.time)
        print(loctime)
        putTime = None
        putDate = None
        if Dates.__contains__(locDate):
            Dates[locDate][loctime] = Dates[locDate][loctime]+1
        else:
            Dates[locDate] = {"12AM":0,"1AM":0,"2AM":0,"3AM":0,"4AM":0,"5AM":0,"6AM":0,"7AM":0,"8AM":0,"9AM":0,"10AM":0,"11AM":0,
                 "12PM":0,"1PM":0,"2PM":0,"3PM":0,"4PM":0,"5PM":0,"6PM":0,"7PM":0,"8PM":0,"9PM":0,"10PM":0,"11PM":0}
            Dates[locDate][loctime] = 1

    print(Dates)
    return Dates



def parseTime(timeString):
    hour = None
    meridiem = None
    StringBuilder = ""
    proc = False
    proc1 = False
    for i in timeString:
        if proc1:
            if str(i) == "A":
                meridiem = "AM"
                break
            if str(i) == "P":
                meridiem = "PM"
                break
        if proc:
            if str(i) == " ":
                proc1 = True
        elif str(i) == ":":
            hour = str(StringBuilder)
            StringBuilder = ""
            proc = True
        else:
            StringBuilder += str(i)
    Time = hour + meridiem
    return Time


def parseDate(dateString):
    Month = None
    Day = None
    StringBuilder = ""
    proc = False
    for i in dateString:
        if proc:
            if str(i) == " ":
                if len(StringBuilder)>0 and Month is None:
                    Month = StringBuilder
                    StringBuilder = ""
                else:
                    continue
            else:
                StringBuilder+=str(i)
        elif str(i) == ",":
            proc = True
    Day = StringBuilder

    Date = Month + " "+Day
    return Date



def main():
    client = pymongo.MongoClient(uri)
    db = client.get_default_database()

    flights = db['flights']
    url = None
    pages = []
    airportCode = str(sys.argv[1])
    url = "https://www.flightradar24.com/data/airports/"+airportCode+"/arrivals"
    driver = webdriver.Chrome("/Users/danielkiselev/PycharmProjects/Beautiful_Flights/chromedriver")
    driver.implicitly_wait(10)
    driver.get(url)
    myElem = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, r'//*[@id="cnt-data-content"]/div/div[2]/div/aside/div[1]/table/tfoot/tr[1]/td/button')))
    page = driver.execute_script('return document.body.innerHTML')
    while True:
        try:
            driver.find_element_by_xpath(r'//*[@id="cnt-data-content"]/div/div[2]/div/aside/div[1]/table/tbody/tr[103]/td')
            driver.find_element_by_xpath(r'//*[@id="cnt-data-content"]/div/div[2]/div/aside/div[1]/table/thead/tr[2]/td/button').click()
        except:
            break
        time.sleep(1)
    while True:
        try:
            driver.find_element_by_xpath(r'//*[@id="cnt-data-content"]/div/div[2]/div/aside/div[1]/table/tfoot/tr[1]/td/button').click()
        except:
            break
        time.sleep(1)
    soup = bs4.BeautifulSoup(driver.page_source, 'html.parser')
    pages.append(soup)
    print(len(pages))
    AirportFlights = []
    for i in pages:
        AirportFlights=getFlights(i, AirportFlights)


    data = parseData(AirportFlights)

    airportData = {}
    airportData[airportCode] = data
    flights.insert(airportData)

    client.close()






if __name__ == "__main__":
    main()
